from pathlib import Path
import math

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "Assets/GreatVoyage/OceanFramework"
REQUIRED = [
    BASE / "Runtime/OceanDataMap.cs",
    BASE / "Runtime/OceanShip.cs",
    BASE / "Runtime/OceanFlowSystem.cs",
    BASE / "Shaders/OceanFlow.compute",
    BASE / "Shaders/OceanSurface2D.shader",
    ROOT / "Docs/FRAMEWORK_CONTRACT.md",
    ROOT / "Docs/ALGORITHM_AND_RENDERING.md",
    ROOT / "Docs/IMPLEMENTATION_PLAN.md",
    ROOT / "AGENT_COMMAND.md",
]

for path in REQUIRED:
    assert path.is_file(), f"Missing: {path}"

csharp = (BASE / "Runtime/OceanFlowSystem.cs").read_text(encoding="utf-8")
compute = (BASE / "Shaders/OceanFlow.compute").read_text(encoding="utf-8")
shader = (BASE / "Shaders/OceanSurface2D.shader").read_text(encoding="utf-8")
required_kernels = ["BuildBaseFlow", "ClearShipDelta", "EmitHullFlow", "ComposeFinalFlow", "AdvanceFoam", "ClearFoam"]
for kernel in required_kernels:
    assert f"#pragma kernel {kernel}" in compute, kernel
    assert f'FindKernel("{kernel}")' in csharp, kernel

for resource in ["_OceanBaseFlowMap", "_OceanShipDeltaMap", "_OceanFinalFlowMap", "_OceanFoamMap"]:
    assert resource in shader, resource
    assert resource in csharp, resource

assert "_LowResolutionData" in compute
assert "_HullWorldVertices" in compute
assert "_ShipDeltaWrite[p]" in compute
assert "_BaseFlowWrite[p]" in compute
assert "_FinalFlowWrite[p]" in compute
assert "world - velocity * _DeltaTime" in compute
assert "world - _DataOrigin" in compute
assert "world * _NoiseFrequency" in compute


def coarse(v0, v1, x):
    normalized = max(0.0, min(1.0, x / 100.0 - 0.5))
    return v0 + (v1 - v0) * normalized

left = coarse(1.0, 3.0, 99.999)
right = coarse(1.0, 3.0, 100.001)
assert abs(left - right) < 0.00005
assert coarse(1.0, 3.0, 50.0) == 1.0
assert coarse(1.0, 3.0, 150.0) == 3.0

for filename in ["OceanDataMap.cs", "OceanShip.cs", "OceanFlowSystem.cs"]:
    source = (BASE / "Runtime" / filename).read_text(encoding="utf-8")
    assert source.count("{") == source.count("}"), filename
assert compute.count("{") == compute.count("}")
assert shader.count("{") == shader.count("}")
print("PASS: static framework and CPU boundary math checks")
print("NOT CHECKED: Unity Editor compilation, GPU shader compilation, GPU output, performance")
