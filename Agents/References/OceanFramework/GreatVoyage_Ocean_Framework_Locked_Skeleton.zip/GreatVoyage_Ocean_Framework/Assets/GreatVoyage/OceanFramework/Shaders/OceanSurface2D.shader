Shader "GreatVoyage/OceanSurface2D"
{
    Properties
    {
        _DeepColor ("Deep Water", Color) = (0.025, 0.14, 0.25, 1)
        _CrestColor ("Wave Crest", Color) = (0.10, 0.36, 0.45, 1)
        _FoamColor ("Foam", Color) = (0.80, 0.96, 0.91, 1)
        _WaveFrequency ("Wave Frequency", Float) = 0.18
        _WaveSpeed ("Wave Animation Speed", Float) = 0.9
        _DebugMode ("Field Debug (0=Surface, 1=Base, 2=Delta, 3=Final, 4=Foam)", Range(0,4)) = 0
        [HideInInspector] _FieldOrigin ("Field Origin", Vector) = (0, 0, 0, 0)
        [HideInInspector] _FieldWorldSize ("Field World Size", Vector) = (400, 400, 0, 0)
        _OceanBaseFlowMap ("Base FlowMap", 2D) = "black" {}
        _OceanShipDeltaMap ("Ship DeltaMap", 2D) = "black" {}
        _OceanFinalFlowMap ("Final FlowMap", 2D) = "black" {}
        _OceanWaveContributionMap ("Future Wave Contributions", 2D) = "black" {}
        _OceanFoamMap ("Foam History", 2D) = "black" {}
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Transparent" "RenderType"="Transparent" }
        Pass
        {
            Name "OceanSurface2D"
            Tags { "LightMode"="SRPDefaultUnlit" }
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes
            {
                float4 positionOS : POSITION;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 worldXY : TEXCOORD0;
            };

            TEXTURE2D(_OceanBaseFlowMap);
            SAMPLER(sampler_OceanBaseFlowMap);
            TEXTURE2D(_OceanShipDeltaMap);
            SAMPLER(sampler_OceanShipDeltaMap);
            TEXTURE2D(_OceanWaveContributionMap);
            SAMPLER(sampler_OceanWaveContributionMap);
            TEXTURE2D(_OceanFinalFlowMap);
            SAMPLER(sampler_OceanFinalFlowMap);
            TEXTURE2D(_OceanFoamMap);
            SAMPLER(sampler_OceanFoamMap);

            CBUFFER_START(UnityPerMaterial)
                float4 _DeepColor;
                float4 _CrestColor;
                float4 _FoamColor;
                float _WaveFrequency;
                float _WaveSpeed;
                float _DebugMode;
                float4 _FieldOrigin;
                float4 _FieldWorldSize;
            CBUFFER_END

            Varyings vert(Attributes v)
            {
                Varyings o;
                float3 world = TransformObjectToWorld(v.positionOS.xyz);
                o.worldXY = world.xy;
                o.positionCS = TransformWorldToHClip(world);
                return o;
            }

            half4 frag(Varyings input) : SV_Target
            {
                float2 uv = (input.worldXY - _FieldOrigin.xy) / max(_FieldWorldSize.xy, 0.00001);
                float2 baseFlow = SAMPLE_TEXTURE2D(_OceanBaseFlowMap, sampler_OceanBaseFlowMap, saturate(uv)).xy;
                float2 shipDelta = SAMPLE_TEXTURE2D(_OceanShipDeltaMap, sampler_OceanShipDeltaMap, saturate(uv)).xy;
                float2 flow = SAMPLE_TEXTURE2D(_OceanFinalFlowMap, sampler_OceanFinalFlowMap, saturate(uv)).xy;
                float foamDensity = SAMPLE_TEXTURE2D(_OceanFoamMap, sampler_OceanFoamMap, saturate(uv)).r;
                if (_DebugMode > 0.5 && _DebugMode < 3.5)
                {
                    float2 debugVector = _DebugMode < 1.5 ? baseFlow : (_DebugMode < 2.5 ? shipDelta : flow);
                    return half4(saturate(float3(debugVector.x * 0.2 + 0.5, debugVector.y * 0.2 + 0.5, length(debugVector) * 0.2)), 1.0);
                }
                if (_DebugMode >= 3.5)
                    return half4(float3(foamDensity, foamDensity, foamDensity), 1.0);

                float flowLength = length(flow);
                float2 direction = flowLength > 0.00001 ? flow / flowLength : float2(0.0, 1.0);
                float2 sideways = float2(-direction.y, direction.x);
                float time = _Time.y;
                float phaseA = dot(input.worldXY, direction) * _WaveFrequency - time * _WaveSpeed;
                float phaseB = dot(input.worldXY, normalize(direction * 0.85 + sideways * 0.53)) *
                    (_WaveFrequency * 1.87) - time * _WaveSpeed * 1.23;
                float waveContribution = SAMPLE_TEXTURE2D(_OceanWaveContributionMap, sampler_OceanWaveContributionMap, saturate(uv)).r;
                float wave = sin(phaseA) * 0.64 + sin(phaseB) * 0.36 + waveContribution;
                float crest = smoothstep(0.05, 0.78, wave);
                float irregular = 0.75 + 0.25 * sin(dot(input.worldXY, float2(0.83, 1.37)) + time * 0.35);
                float foam = saturate(foamDensity * irregular + pow(crest, 6.0) * 0.09);
                float3 water = lerp(_DeepColor.rgb, _CrestColor.rgb, crest);
                float3 color = lerp(water, _FoamColor.rgb, foam);
                return half4(color, 1.0);
            }
            ENDHLSL
        }
    }
}
