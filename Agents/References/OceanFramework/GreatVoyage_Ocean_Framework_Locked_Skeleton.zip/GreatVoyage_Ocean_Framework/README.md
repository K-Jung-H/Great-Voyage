# Great Voyage — 2D Ocean Flow Framework (Locked Skeleton)

이 패키지는 **재설계를 요청하는 프롬프트만이 아니라, 바꾸면 안 되는 핵심 데이터 파이프라인과 실제 C#/HLSL 파일**을 포함한다.

## 지정된 구조

`LowResolutionOceanDataMap → (Bilinear + World-space Seeded Noise) → BaseFlowMap → ShipDelta → FinalFlowMap → FoamHistory → UnifiedOceanShader`

- Ocean Data의 셀 크기는 예시 100×100 월드 단위이며, FlowMap 텍셀 크기와 무관하다.
- Ocean Data의 `MainDirection`은 **방향 편향/가중치**이며 최종 파도 셀이나 파도 영역의 정의가 아니다.
- 동일한 데이터·Seed·월드 좌표에서 BaseFlowMap 샘플은 고정된 결과를 산출한다.
- **완성된 BaseFlowMap이 먼저 존재**한 뒤, 선박 주변의 BaseFlowMap 값에 선체 움직임을 반영한다.
- 선박은 BaseFlowMap에 쓰지 않는다. ShipDelta만 갱신하고 Compose 단계에서 FinalFlowMap을 생성한다.
- FoamHistory는 위치와 시간을 가진 별도 누적 필드다.
- 독립적인 스프라이트 또는 V자 Wake 이미지의 오버레이를 금지한다.

## 읽기 순서

1. [FRAMEWORK_CONTRACT.md](Docs/FRAMEWORK_CONTRACT.md): **변경 불가** 아키텍처 및 데이터 계약
2. [ALGORITHM_AND_RENDERING.md](Docs/ALGORITHM_AND_RENDERING.md): GPU 커널·연산·기능 범위
3. [IMPLEMENTATION_PLAN.md](Docs/IMPLEMENTATION_PLAN.md): 에이전트 단계별 작업·검증 게이트
4. [AGENT_COMMAND.md](AGENT_COMMAND.md): 다른 구현 에이전트에 그대로 전달할 명령

## 포함된 Unity 파일

- `OceanDataMap.cs`: 저해상도 방향 가중치 데이터, CPU bilinear 참고 샘플러
- `OceanShip.cs`: PolygonCollider2D 선체 데이터와 선박의 이동/회전 입력
- `OceanFlowSystem.cs`: 고정된 CPU/GPU 파이프라인과 수명 관리
- `OceanFlow.compute`: Base 생성, Hull 교란, Final 합성, Foam 수송 커널
- `OceanSurface2D.shader`: URP 2D XY 수면 셰이더의 **최소 미리보기**. `_DebugMode` 1(Base), 2(ShipDelta), 3(Final), 4(Foam) 확인용 경로 포함
- `Tests~/OceanDataMapTests.cs`: 선택 설치용 Unity Test Framework 테스트

## Unity 연결

1. `Assets/GreatVoyage/OceanFramework` 폴더를 Unity 프로젝트 `Assets`에 복사한다.
2. URP 프로젝트에서 `GreatVoyage/OceanSurface2D` 머티리얼을 만든다.
3. XY 평면의 MeshRenderer(Quad 등)에 머티리얼을 할당하고, FlowMap의 월드 영역에 맞춰 배치한다.
4. `OceanDataMap` ScriptableObject를 생성하고 셀 크기(예: 100), MainDirection, Speed, NoiseStrength를 설정한다.
5. 빈 게임 오브젝트에 `OceanFlowSystem`을 추가해 DataMap·`OceanFlow.compute`·수면 Renderer를 연결한다.
6. 선박에 `PolygonCollider2D`와 `OceanShip`을 추가한다. `OceanFlowSystem`에 등록하거나 `RegisterShip`을 호출한다.
7. Play 실행 후 Base/Final FlowMap을 GPU 디버거로 확인한다.

프로토타입 기본값: Data 셀 한 변 100 월드 단위, FlowMap 윈도우 400×400 월드 단위, FlowMap 512×512 픽셀이다. **이 값들은 예시이며 고정 계약이 아니다.**

## 범위와 주의사항

이 코드는 **Framework Skeleton 및 작동 경로를 보여주는 시작 구현**이다. Kelvin/Divergent Wave의 고품질 파형, 시각적으로 완성된 Ocean 패턴, 복잡한 선체의 정밀 수류, 청크 스트리밍, 계산 패스 최적화는 아직 구현하지 않았다. `OceanSurface2D.shader`는 결과를 관찰하기 위한 최소 시각화이지 최종 품질 기준이 아니다.

Unity 2022.3 이상 URP/Compute Shader 지원 환경을 전제로 작성했으나, **실제 사용자의 Unity 프로젝트에서 에디터 컴파일·실기기 GPU 검증은 수행하지 않았다.** 프로젝트의 URP 설정, 플랫폼별 Shader Compiler, 정확한 Unity 버전은 별도 확인 대상이다.

현재 Skeleton은 **단일 고정 월드 윈도우와 단일 경로 PolygonCollider2D**에 대응한다. 복수 경로/구멍을 가진 Collider나 수면 윈도우 이동을 지원한다고 주장하지 않는다.
