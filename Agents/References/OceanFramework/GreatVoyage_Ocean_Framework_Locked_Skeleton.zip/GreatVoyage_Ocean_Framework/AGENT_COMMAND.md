# 다른 개발 에이전트에 전달할 지시문

다음 지시를 우선 적용한다. 제공된 `GreatVoyage_Ocean_Framework` 패키지의 `Docs/FRAMEWORK_CONTRACT.md`와 `Assets/GreatVoyage/OceanFramework/`의 C#/Compute/Shader 파일이 이번 설계의 **확정된 Framework**다.

## 수행할 작업

1. 현재 Unity 프로젝트의 버전, URP Renderer, Ocean/Ship/TileMap 코드를 조사한다.
2. 제공된 Skeleton을 현재 프로젝트에 적합하게 **연결**한다.
3. 제공된 Skeleton의 컴파일 실패나 API 호환성 문제만 프로젝트 버전에 맞게 수정한다.
4. `Docs/IMPLEMENTATION_PLAN.md`의 Phase 0~6을 실제 프로젝트 기준의 업무 목록으로 구체화한다.
5. 각 Phase의 검증 방법, 연관 파일, GPU 필드 채널, 실행 순서, 위험을 기재한다.
6. Skeleton에서 미구현인 기능을 명확히 식별하되, 미리 전체 알고리즘을 새로 구현하지 않는다.
7. 사용자 승인 전에는 설계서·Skeleton 정리와 Phase 0~1 통합 검증을 우선한다.

## 절대 재해석 금지

- 저해상도 OceanDataMap의 각 셀은 큰 월드 영역(예: 100×100)의 `MainDirection` 편향을 저장한다.
- DataMap은 실제 Wave의 개별 Rect/Region을 정의하지 않는다.
- MainDirection으로 모든 픽셀의 파도를 곧바로 렌더링하지 않는다.
- **Bilinear + 고정 Seed의 월드 좌표 Noise로 BaseFlowMap을 먼저 완성한다.**
- 선박은 **완성된 BaseFlowMap**을 주변에서 샘플링해 상대 수류를 계산한다.
- 배의 Collider2D 외곽 정보와 속도로 `ShipDeltaMap`을 만들고 BaseFlowMap을 보존한다.
- `FinalFlowMap = BaseFlowMap + ShipDeltaMap`의 의미를 유지한다.
- Foam은 별도 History Buffer에 누적하고 FinalFlowMap으로 수송한다.
- Ocean Shader는 FinalFlowMap 및 FoamHistory를 읽어 단일 수면을 그린다.
- 유체 물리 솔버, FFT 바다 시뮬레이터, SDF 전체 재생성, 스프라이트 오버레이로 대체하지 않는다.

## 설계 선택 시 제약

`OceanDataMap`, `OceanShip`, `OceanFlowSystem`의 기존 공개 API와 `BuildBaseFlow`, `EmitHullFlow`, `ComposeFinalFlow`, `AdvanceFoam` 등 Compute kernel의 입·출력 책임을 유지한다. 추가 기능은 기존 파이프라인에 플러그인 형태로 붙인다.

Phase 3의 Bow Flow와 Hull-side Flow 검증을 완료하기 전에는 Wake·Foam 미세 품질 구현에 진입하지 않는다. 고정 단일 Field Window에서 먼저 정확성을 검증하고, 청크 스트리밍은 후속 최적화로 처리한다.

## 보고 형식

- 현재 프로젝트 환경 및 실제 코드 조사 결과
- 제공 Skeleton과 기존 코드의 매핑표
- 그대로 유지할 파일 / API 호환성 수정할 파일 / 추가할 파일
- Phase별 상세 구현 계획 및 완료 기준
- 지금 당장 검증 가능한 테스트와 미검증 항목
- Framework Contract과 충돌하는 변경 제안이 있다면 별도 승인 요청

**중요: 별도 시스템을 새로 만들거나 기존 데이터 파이프라인을 재해석하지 않는다.**
