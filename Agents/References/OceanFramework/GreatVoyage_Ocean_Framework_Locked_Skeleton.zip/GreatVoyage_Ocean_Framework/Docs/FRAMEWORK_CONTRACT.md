# FRAMEWORK_CONTRACT — 변경 불가 핵심 계약

## 0. 권위와 변경 범위

이 문서는 본 Framework의 아키텍처 계약이다. 구현 에이전트는 *같은 목표를 다른 구조로 다시 해석해서는 안 된다.*

- **고정:** 데이터의 의미, 7단계 파이프라인 순서, 리소스 쓰기 권한, 좌표계, 결정론, 선체 입력 경로, GPU 필드의 기본 채널 의미.
- **조정 가능:** 타일 크기, FlowMap 픽셀 해상도, 노이즈의 형태/주파수, 시각 파도 함수, 선체 Flow 근사의 내부 수식, GPU 최적화.
- **금지:** Ocean Data Map을 Wave Region Map으로 재정의; 각 타일이 파도 영역을 하나씩 담당하도록 전환; BaseFlowMap 생략 후 Ocean Shader에서 원본 타일을 직접 파도에 적용; 선박이 BaseFlowMap을 직접 수정; 유체 솔버 도입; Sprite Overlay로 수류/포말/항적 표현.

## 1. 불변 데이터 흐름

```text
OceanDataMap [CPU; coarse cells, MainDirection bias]
       |
       +--> GPU coarse data texture [RGBAHalf; XY=MainDirection, Z=Speed, W=NoiseStrength]
                      |
                      v
           BuildBaseFlow COMPUTE [only on data/seed/window changes]
           Bilinear(coarse, worldXY) + StableNoise(worldXY, seed)
                      |
                      v
              BaseFlowMap [GPU; read-only after build]
                      |
    Ship PolygonCollider2D + Transform/velocity/angular velocity
                      |
                      v
        EmitHullFlow [sample COMPLETED BaseFlowMap]
                      |
                      v
          ShipDeltaMap [GPU; cleared and rebuilt each frame]
                      |
                      v
             ComposeFinalFlow [Base + ShipDelta]
                      |
                      v
              FinalFlowMap [GPU; current frame]
                      |
                      +----> AdvanceFoam [FoamHistory ping-pong]
                      |                   |
                      v                   v
             Unified Ocean Surface Shader [Flow + Foam + waves]
```

`BaseFlowMap`은 `OceanDataMap` 자체도, 타일별 파도 마스크도 아니다. **저해상도 방향 편향을 연속적으로 보간하고 결정론적 Noise를 결합하여 미리 완성한 고해상도/중해상도 공간 방향장이다.**

## 2. 엄격한 공간 및 시간 계약

| 필드 | 공간 | 값의 의미 | 시간 의존성 | 수정 주체 |
|---|---|---|---|---|
| `OceanDataMap` | 월드 XY의 coarse cell | `MainDirection` 편향, 속도/Noise 강도 | 타일 편집 시 | CPU OceanDataMap |
| `BaseFlowMap` | 월드 XY의 FlowMap texel | 완성된 배경 유속 Vector2 | **고정** | BuildBaseFlow 전용 |
| `ShipDeltaMap` | 동일 FlowMap window | 선박으로 인한 유속 변화 Vector2 + Foam Source | 현재 프레임 | ClearShipDelta / EmitHullFlow 전용 |
| `FinalFlowMap` | 동일 FlowMap window | 현재 기본 유속 + 선박의 영향 | 매 프레임 | ComposeFinalFlow 전용 |
| `FoamHistory` | 동일 FlowMap window | 과거부터 누적된 Foam Density | 누적/감쇠 | AdvanceFoam 전용 |
| Ocean Shader | 월드 XY | 화면 색상·파도·Foam | 매 프레임 | 읽기 전용 |

- 2D 게임은 **Unity 월드 XY**를 사용한다. 수면 메시 Z는 렌더 순서용이며 Flow 계산에 참여하지 않는다.
- 선박 좌표, Collider 좌표, DataMap, Base/Final FlowMap 샘플 좌표는 **모두 월드 XY**를 사용한다.
- `worldOrigin`은 Ocean DataMap 첫 셀의 **좌하단 모서리**, `fieldWorldOrigin`은 FlowMap 윈도우의 좌하단 모서리다.
- Ocean DataMap 셀 값은 **셀 중앙의 샘플**이다. 타일 A의 (0,0) 셀 중심은 `origin + (50,50)` (cellSize=100일 때).
- 임의 세계 좌표 `P`는 인접한 셀 **중앙값 네 개**를 bilinear 보간한다. 각도 자체를 직접 보간하지 않는다.
- FlowMap의 (i,j) 픽셀 중심은 `fieldOrigin + ((i+0.5)/width,(j+0.5)/height)*fieldWorldSize`이다.
- **Data cell 크기와 FlowMap 텍셀 크기는 독립**이다. 100×100 Data cell을 수많은 Flow texel이 공유한다.

## 3. 고정 수식 및 갱신 순서

```text
C(P)       = BilinearSample(OceanDataMap, P)
N(P,seed)  = ContinuousDeterministicNoise(P,seed)
Base(P)    = Normalize(C.direction + C.noiseStrength * N(P,seed)) * C.speed
Ship(P,t)  = HullGuidedDelta(P, Base(P), hullGeometry(t), hullVelocity(t))
Final(P,t) = Base(P) + Ship(P,t)
Foam(t+dt) = AdvectAndDissipate(Foam(t), Final(t), dt) + FoamSource(Ship(t))*dt
```

중요:
1. **Base(P)는 정적**이다. 시간과 선박에 의존하지 않는다.
2. 선박이 이동하지 않더라도 해류와의 상대속도에 의한 교란은 가능하다.
3. `Ship`은 선박의 로컬 픽셀만 갱신하며 선박 수가 늘어나면 같은 ShipDelta에 누적한다.
4. 선박이 떠나면 해당 선박의 Delta는 사라지지만 FoamHistory는 수명 동안 남는다.
5. Foam이 수면 위에 붙는 `SpriteRenderer`나 V자 이미지는 이 데이터 흐름에 존재하지 않는다.
6. 바다의 파도 **애니메이션**은 시간 의존적이어도, Base Flow의 공간적 구조는 같은 좌표에서 변하지 않는다.

## 4. CPU/GPU 리소스 데이터 계약

| 리소스 | 포맷 | 채널 R/G/B/A | 생성/소유 |
|---|---|---|---|
| `LowResolutionData` | Texture2D RGBAHalf | 방향 X / 방향 Y / Speed / NoiseStrength | OceanFlowSystem + OceanDataMap |
| `BaseFlowMap` | RWTexture ARGBHalf | 속도 X / 속도 Y / speed / 0 | OceanFlowSystem, BuildBase 전용 |
| `ShipDeltaMap` | RWTexture ARGBHalf | delta X / delta Y / FoamSource / Influence | OceanFlowSystem, Ship kernels |
| `FinalFlowMap` | RWTexture ARGBHalf | 최종 속도 X / Y / speed / Ship Influence | OceanFlowSystem, Compose 전용 |
| `FoamHistory A/B` | RWTexture ARGBHalf | Density / 0 / 0 / 0 | OceanFlowSystem, Ping-Pong |
| `WaveContributionMap` (Phase 5) | RWTexture ARGBHalf | Height Contribution / Crest Weight / Reserved / Reserved | 후속 Wave Generation 모듈 |
| `HullWorldVertices` | ComputeBuffer (float2) | 월드 XY 다각형 점 열 | OceanShip |

ARGBHalf는 기능 검증용 고정 포맷이다. RHalf/약식 포맷으로의 최적화는 **값의 의미를 유지한 상태에서** 검증을 통과한 후에만 수행한다.

## 5. 필수 공개 API / 핵심 클래스

```text
OceanDataMap.Configure(origin, gridSize, tileWorldSize)
OceanDataMap.GetCell(x, y)
OceanDataMap.SetCell(x, y, cell)
OceanDataMap.SampleInterpolated(worldPosition)
OceanDataMap.BuildGpuPayload()
OceanShip.SyncMotion(deltaTime)
OceanShip.InvalidateHull()
OceanShip.PrepareHull()
OceanFlowSystem.RegisterShip(ship)
OceanFlowSystem.UnregisterShip(ship)
OceanFlowSystem.MarkOceanDataDirty()
OceanFlowSystem.BaseFlowMap
OceanFlowSystem.FinalFlowMap
OceanFlowSystem.FoamHistory
```

핵심 타입이나 프로퍼티가 없어지는 변경은 계약 위반이다. 추가 API는 가능하나 위 API를 대체할 수 없다.

## 6. 셰이더/컴퓨트 고정 진입점

```text
BuildBaseFlow
ClearShipDelta
EmitHullFlow
ComposeFinalFlow
AdvanceFoam
ClearFoam
```

명칭과 입력/출력 텍스처의 책임을 유지한다. 후속 파형은 `WaveContributionMap`에 기록하며 Ocean Surface Shader의 `_OceanWaveContributionMap`에서만 샘플링한다. Wave의 R 채널은 추가 파형 높이 성분, G는 파도 마루 가중치로 예약한다. 새 모듈 추가는 가능하나 **단일 독립 FlowMap으로 전부를 대체하거나, BaseFlow 생성 단계를 건너뛰는 것은 금지**한다.

## 7. 확정적으로 구현하지 않은 기능

- 임의 복합 Collider2D의 다중 경로/홀 분해
- Streaming Chunk/Clipmap과 월드 윈도우의 재중심화
- 물리적으로 충실한 Kelvin/Divergent Wave의 파면
- 고품질 Bow/Stern Foam 패턴과 Time-aware Wave Source
- FlowMap 내 장애물 경계의 유체 비관통 조건/질량 보존
- GPU 외부 정합성, 모바일 전체 범위 성능

이 항목들은 미구현이며 존재하는 것처럼 간주하지 않는다. 구현 시 **현 계약에 모듈을 붙여야 하며 계약을 뒤집을 수 없다.**
