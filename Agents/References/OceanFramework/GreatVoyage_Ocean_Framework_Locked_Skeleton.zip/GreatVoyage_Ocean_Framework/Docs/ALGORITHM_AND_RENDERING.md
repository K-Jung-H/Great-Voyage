# ALGORITHM_AND_RENDERING — 정확한 구현 의미

## 1. Coarse Data → Base FlowMap

Ocean Tile의 크기 `S=100`은 예시다. 이 셀은 100×100 픽셀도, 파도가 발생하는 100×100 크기의 고정 영역도 아니다. `MainDirection`은 최종 방향을 유도하는 저해상도 샘플 값이다.

셀 중앙 좌표 보간을 고정한다.

```text
q = (worldXY - dataWorldOrigin) / tileWorldSize - (0.5, 0.5)
i = floor(q)
u = frac(q)
C(worldXY) = bilinear(Cells[i], Cells[i+(1,0)], Cells[i+(0,1)], Cells[i+(1,1)], u)
BaseFlow(worldXY) = normalize(C.MainDirection + C.NoiseStrength * StableNoise(worldXY, seed)) * C.Speed
```

외곽은 가장자리 Data cell 값으로 확장(clamp)한다. Direction 값이 상쇄되어 0이 되는 위치는 0벡터 처리한다. 이 경우 BaseFlow는 0이 된다. 장기적으로는 `MainDirection`과 `Speed`의 혼합 정책을 조정할 수 있지만 영역 분리로 우회할 수는 없다.

`StableNoise`는 시간에 독립적인 월드 좌표 기반의 smooth value noise다. 각 타일의 독립 Seed/경계 UV를 쓰지 않는다. `OceanFlow.compute`의 unsigned integer hash와 smooth interpolation이 기준 구현이다.

## 2. Base FlowMap 갱신 정책

- `BuildBaseFlow`는 Coarse Data, Seed/Noise 값, Field Window/해상도가 변경될 때만 다시 실행한다.
- `OceanFlowSystem.MarkOceanDataDirty()`를 호출하면 다음 업데이트에서 Coarse 데이터를 재업로드한다.
- 기본 데이터에 아무 변화가 없다면 선박이 이동해도 Base를 재생성하지 않는다.
- BaseFlow는 생성 완료 후 **모든 Ship 및 Compose kernel에서 읽기 전용**이다.
- Chunk 기반 확장은 World XY에서 같은 좌표가 항상 같은 `Base(P)`를 만들도록 world-aligned offset을 유지한다.

## 3. Ship Flow의 좌표계

Hull Polygon은 Collider2D의 실제 local vertex와 `offset`을 Unity Transform을 거쳐 월드 XY로 옮긴다. `PolygonCollider2D.pathCount==1`만 현재 구현의 유효 조건이다.

Hull의 각 경계점 근처:

```text
hullPointVelocity = shipLinearVelocity + angularVelocity * perpendicular(hullPoint - shipCenter)
relativeWaterVelocity = BaseFlow(P) - hullPointVelocity
incoming = max(0, -dot(relativeWaterVelocity, outwardNormal))
sideStream = max(0, dot(-relativeWaterVelocity, shipForward))
             * (1 - abs(dot(outwardNormal, shipForward)))
influence = smoothstep(distanceToHull / interactionRadius)
shipDelta = influence * (outwardNormal * incoming + rearwardTangent * sideStream * sideGain)
foamSource = influence * emission * (incoming + 0.3 * sideStream)
```

수식은 **선박의 선단에서 양쪽으로 갈라지고 측면을 따라 후방으로 흐르는 효과를 만들기 위한 첫 근사**이다. 이 방정식을 물리적으로 정확한 비압축성 유체라고 주장하지 않는다. 비대칭 선형, 회전, 역류, 파도 방향과 선체 접선의 관계는 Phase 3~4에서 시각화로 검증한다.

현재 `EmitHullFlow`는 경계에서 가장 가까운 점을 찾고, 다각형 winding을 확인해 outward normal을 결정한다. 선체 내부는 변화량을 쓰지 않는다. 다수 선박의 기여는 같은 ShipDelta에 순차 누적한다. 이 경로는 FlowMap 전체를 매 선박마다 탐색하지 않고 경계 주변의 사각 영역만 Dispatch한다.

## 4. Final FlowMap의 의미

```text
FinalFlowMap.xy = BaseFlowMap.xy + ShipDeltaMap.xy
FinalFlowMap.z  = length(FinalFlowMap.xy)
FinalFlowMap.w  = ShipDeltaMap.w
```

기본 수류는 물체가 지나가도 지워지지 않는다. 매 프레임 Delta를 먼저 0으로 Clear하기 때문에 이전 프레임의 선박 움직임이 우발적으로 누적되지 않는다.

## 5. Foam History와 후방 잔류

```text
previousWorld = P - FinalFlow(P,t) * dt
newFoam(P) = saturate(SampleBilinear(oldFoam, previousWorld) * exp(-decay * dt)
                      + ShipDelta.FoamSource(P) * dt)
```

GPU RenderTexture 두 장을 Ping-Pong한다. 히스토리 좌표는 카메라 스크린이 아니라 월드 XY를 기반으로 한다. 선박이 떠나도 남아 있는 밀도는 즉시 사라지지 않는다. 이 수송 근사는 유체 압력을 계산하지 않는다.

현재 코드는 FlowMap 윈도우가 고정되어 있다고 가정한다. 윈도우 재배치 또는 Chunk unload 후에도 히스토리를 보존하려면 별도 world-aligned reproject/persistent chunk storage를 먼저 구현해야 한다. **자동 지원한다고 가정하지 않는다.**

## 6. Ocean Surface Shader

수면 셰이더가 직접 `OceanDataMap`을 읽어 새로운 Flow를 만든다면 아키텍처 오류다. 추가 파동은 후속 `WaveContributionMap` R(height)/G(crest)을 이용하며, 현재 Shader는 R 입력용 슬롯만 예약해 놓았다. 최종 셰이더 입력은 **FinalFlowMap + FoamHistory (+ 향후 WaveContribution)**다.

현재 셰이더는 FinalFlow 방향을 이용한 두 개의 간단한 주기적 파동 패턴과 FoamDensity를 렌더링한다. 이는 데이터 전달과 수면에서의 반응을 확인하는 **미리보기**이지 완성된 바다 파동이나 고품질 Bow Foam이 아니다.

최종 품질 구현 시에도 다음을 유지한다.

1. Ocean Shader는 FinalFlowMap을 읽는다.
2. Flow 변화는 수면의 파도 패턴 방향·위상 또는 이동 경로에 반영한다.
3. FoamHistory는 **밀도 데이터**이며 이를 패턴화해 최종 Foam Color를 얻는다.
4. Local/Circular/Wake 파도는 별도의 스프라이트 레이어가 아닌 WaveContribution 필드 또는 수학적 함수로 전달한다.
5. 지역별 Shader 경계는 월드 좌표 기반 샘플과 부드러운 영향 함수로 없앤다.

**주의:** `dot(worldXY, localDirection(P))`식의 초기 파도 패턴은 방향장이 급격히 변할 때 과도한 압축/늘어짐을 만들 수 있다. Phase 2와 6에서 시간 안정적인 Flow-Aware Phase Mapping을 시각적으로 검증해야 한다. 별도의 거대한 CFD 솔버를 도입해서 해결하지 않는다.

## 7. 연산 및 성능 예상

- BaseFlow 생성: FlowMap의 픽셀 수에 비례. 바다 데이터 수정 시에만 실행.
- ShipDelta: 선박별 국소 bounding rectangle의 픽셀 수 × 선체 꼭짓점 수에 비례. **여기가 현재 Skeleton의 주요 병목 후보.**
- Compose: FlowMap 전체 픽셀 수만큼 단순 Vector 더하기.
- Foam: FlowMap 전체 픽셀 수만큼 이전 Foam 4점 bilinear + 이동/감쇠.
- Ocean Shader: 수면이 화면에 차지하는 픽셀 수에 비례.

해상도 예시 512×512, RGBAHalf 텍스처 5장 사용 시 GPU 리소스 데이터 총량은 약 10 MiB이다(512×512×8 bytes×5). Coarse 데이터 및 Hull 버퍼/렌더러 별도. 실사용 프레임 시간이나 지원 선박 수는 측정하기 전까지 확정하지 않는다.

## 8. 반드시 잡아야 하는 경계 조건

- Ocean DataMap 내부 및 인접 셀 경계에서 MainDirection 전환은 부드러워야 한다.
- Seed가 같으면 동일 WorldXY의 BaseFlow는 매번 같아야 한다.
- 선박이 없어지면 FinalFlow는 BaseFlow로 복귀해야 한다.
- 선박 주변 Flow가 바다 전체/카메라 위치를 따라 움직여서는 안 된다.
- 정지 선박(해류 0)은 Flow 교란/포말 생성이 없어야 한다.
- 해류가 존재하면 정지 선박에도 상대 수류가 있을 수 있다.
- 선박이 이동하는 중 BaseFlow는 수정되면 안 된다.
- 서로 다른 두 선박이 동시에 존재해도 렌더링 순서가 Field 내용을 뒤집으면 안 된다. 현재 Delta는 누적합이며 Float16 포화 위험을 별도 검사한다.
