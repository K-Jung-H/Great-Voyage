# IMPLEMENTATION_PLAN — Skeleton 기반 단계별 개발 계획

## 목적

이 문서는 제로베이스로 다시 설계하는 문서가 아니다. `FRAMEWORK_CONTRACT.md`와 실제 Skeleton의 **고정 데이터 흐름을 구현·검증·고도화하는 작업 명세**다.

## 작업 전 조건

- Unity 프로젝트 버전, URP 사용 여부, 2D Renderer 또는 Forward Renderer, 지원 플랫폼을 확인한다.
- 프로젝트의 기존 Ocean, Ship, TileMap, Shader 코드와 자산을 먼저 조사한다.
- 기존 구현이 본 계약과 충돌하면 무단 삭제하지 않고 충돌 목록·마이그레이션 방안을 작성한다.
- **Architecture Contract을 임의 수정하지 않는다.** 기술적으로 수정이 필요한 경우 증명 가능한 문제와 최소 수정안을 별도 변경 요청으로 제출한다.
- Unity Editor에서 실제 컴파일/실행을 확인할 수 없는 경우 검증을 완료했다고 보고하지 않는다.

## Phase 0 — 프로젝트 통합 및 현재 상태 진단

**입력:** 실제 프로젝트, 제공된 Skeleton.

**작업:** `OceanFlowSystem`과 단일 XY 수면 Quad를 연결한다. 기존 렌더링과 간섭이 없는 테스트 씬을 만든다. `OceanDataMap`을 테스트용 방향 데이터로 설정한다. `OceanShip`에 정확한 선체 접수 PolygonCollider2D를 지정한다.

**게이트:** Unity 콘솔에 C#/HLSL 오류가 없고, 지정된 GPU에서 6개 Compute kernel의 Dispatch가 이루어진다.

## Phase 1 — 저해상도 OceanDataMap / BaseFlowMap

**실제 Skeleton:** `OceanDataMap.cs`, `OceanFlow.compute:BuildBaseFlow`, `OceanFlowSystem.UploadDataMap`.

**작업:** 기본 데이터 편집 UI 또는 기존 타일맵 데이터를 OceanDataMap 포맷으로 매핑한다. 중앙 샘플링, 타일 경계 bilinear, 고정 Seed Noise, 월드 좌표 변환을 검증한다. Visual Debug: BaseFlowMap R/G 벡터 그리드와 방향 색상.

**검증 시나리오:**

1. 월드 100×100 셀 A/B에 서로 다른 방향을 주고 경계 좌우 ±ε의 Flow 값 연속성을 확인한다.
2. 같은 worldXY/Seed/원본 데이터로 100번 평가해 같은 Base 결과를 확인한다(GPU half float 오차 범위는 수치화).
3. 선박 이동/회전 중 BaseFlowMap checksum이 변하지 않는지 확인한다.
4. Base 셀 크기를 100에서 200으로 바꾸어도 FlowMap 텍셀 수와 독립적으로 동작하는지 확인한다.

**완료 기준:** 데이터→완성된 BaseFlowMap 과정이 존재하고, 선박과 시간에 독립적인 결과가 나온다.

## Phase 2 — Base Ocean Shader / 시각적 파도

**실제 Skeleton:** `OceanSurface2D.shader`.

**작업:** Base Flow 방향과 강도를 기반으로 바다 전체 파도 패턴을 정돈한다. 현 2중 사인파는 진단용이므로 무작위 세부 파형/거품을 여기서 확정하지 않는다. Flow 방향이 급변하는 영역에서 파형 압축·뒤틀림·위상 끊김을 검증한다.

**완료 기준:** 스프라이트 오버레이 없이 월드 좌표에 안정적인 파도 표현, 셀 경계 없이 이동하는 애니메이션.

## Phase 3 — Collider2D 입력과 ShipDelta

**실제 Skeleton:** `OceanShip.cs`, `OceanFlow.compute:EmitHullFlow`, `OceanFlowSystem.EmitHullFlow`.

**작업:** 선수(+Local Y), 선미, 좌현/우현 방향을 확인한다. 물에 닿는 실제 `PolygonCollider2D`의 path0을 쓴다. Hull world vertex와 가장 가까운 경계점, normal, tangent, velocity, impact strength를 GPU 디버그 뷰로 검증한다. 배 이동/회전/정지/역진/측류를 테스트한다.

**완료 기준:** 선수가 좌우 수류를 유도하고 선체 양측 방향장이 연속적으로 후방을 향한다. 정지 선박/해류 정지에서는 가짜 수류가 생기지 않는다.

**절대 중지 조건:** 선수에서 갈라지는 패턴이 아닌 단순 원형 파동·V자 스프라이트만 보이면 다음 Phase로 넘어가지 않는다.

## Phase 4 — FinalFlow 합성과 Foam History

**실제 Skeleton:** `ComposeFinalFlow`, `AdvanceFoam`.

**작업:** Base 변경 없이 Delta를 더해 최종 Field를 만든다. 선체 경계에서 FoamSource를 생성해 History로 수송한다. Bow Foam, Hull-side Foam, Stern Foam의 강도/모양을 분리하되 히스토리는 계속 **하나의 FoamHistory 계층**에 저장한다.

**검증 시나리오:**

- 배가 이동하면 선수·선측에서 포말이 생성되어 월드 XY를 따라 이동한다.
- 배를 제거해도 Foam이 즉시 지워지지 않고 감쇠한다.
- 다른 선박 두 척이 겹쳐도 이전 선박의 포말이 덮어써지지 않는다.
- 카메라만 이동해도 수면 효과의 월드 좌표가 변하지 않는다.

**완료 기준:** 접수부와 측면 포말이 배에 붙는 이미지가 아니라 월드 공간에 남는 데이터로 보인다.

## Phase 5 — Wake / Divergent / Local Circular Waves

현재 Skeleton은 **고품질 Wake/Divergent Wave 솔버를 구현하지 않는다.** 이 단계에서 다음 중 하나를 기존 FinalFlow 이후에 추가한다.

- `WaveContributionMap`은 별도로 유지한다. R 채널은 파형 높이 기여량, G는 마루 가중치로 예약한다.
- 내부 원천은 선박 궤적/발생시각/진행 방향을 가진 emitter 또는 월드 공간의 wave history일 수 있으나, **최종 출력은 반드시 `WaveContributionMap`**으로 통합한다.

어떤 방식이든 다음을 준수한다.

1. BaseFlowMap을 바꾸지 않는다.
2. 별도의 스프라이트 오버레이를 생성하지 않는다.
3. 선체의 실제 위치, 속도, 폭 및 선단 방향을 파형 입력으로 사용한다.
4. V자 영역 경계가 아니라 양측 **사선 파도 마루**를 만들어야 한다.
5. 원형 파동도 같은 월드 좌표 기반 WaveContribution 경로를 사용한다.

**완료 기준:** Bow/Hull Flow를 방해하지 않으면서 항적이 월드 공간에서 생겨나 감쇠한다.

## Phase 6 — 성능·스트리밍·정밀도

현재 Skeleton은 *고정된 FlowMap window*다. 월드가 커지면 다음 순서로 확장한다.

1. GPU Profiling으로 Hull vertex loop, Foam pass, 전체 FlowMap pass 비용 측정.
2. 선박 영향 마스크 범위 계산을 보정해 국소 Dispatch 최적화.
3. Foam/Flow History를 Chunk 기반 월드 고정 버퍼 또는 원점 정렬된 Clipmap으로 확장.
4. Recenter 때 기존 FoamHistory를 월드 공간 좌표로 보존하는 검증 수행.
5. 데이터 업데이트는 dirty regions/dirty chunks만 업로드.
6. 포맷 최적화 및 렌더링 패스 결합은 결과 동등성을 테스트한 뒤 적용.

**완료 기준:** 타깃 GPU별 측정치를 포함한 성능 리포트와 설정별 시각 비교 자료.

## 필수 결과물

- `INTEGRATION_REPORT.md`: 현재 Unity 프로젝트와 Skeleton의 실제 연결 결과 및 차이
- `GPU_FIELD_DEBUG.md`: Base/ShipDelta/Final/Foam 각 채널 화면과 값의 범위
- `VISUAL_ACCEPTANCE.md`: 선수 분기·선측 이동·포말 잔류·타일 경계 시각 검증
- `PERFORMANCE_REPORT.md`: GPU Dispatch별 측정된 시간, 해상도/선박 수별 비교

## 금지하는 완료 보고

- 단순 파도 패턴만 보이는데 선체 Flow가 구현됐다고 보고
- CPU 셀 보간만 맞는데 GPU FlowMap 보간도 검증됐다고 보고
- 포말을 흰색 선체 테두리로 그려 놓고 Foam Advection이라고 보고
- Kelvin처럼 보이는 V자 무늬만 만들고 실제 Divergent Wave가 구현됐다고 보고
- 에디터 빌드/실기기 테스트 없이 성능 목표를 만족했다고 보고

## 에이전트 변경 승인 규칙

고정 데이터 계약을 바꾸고 싶은 경우, 먼저 다음을 제출한다.

1. 기존 Skeleton의 어떤 경로가 왜 실패하는지의 재현 사례
2. 계약을 바꾸지 않는 최소 수정안
3. 그래도 불가능한 경우에만 계약 변경 제안
4. 변경 전후 수치·시각적 비교 기준

**유저 승인 없이 단계 3과 4를 실제 코드에 반영할 수 없다.**
